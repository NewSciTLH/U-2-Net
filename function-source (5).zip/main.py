from utils import utils
from google.cloud import logging
import os  
from google.cloud import storage
from google.cloud import bigquery
from pathlib import Path

my_file = Path("storagekey.json")
if my_file.is_file():
    storage_client = storage.Client.from_service_account_json(my_file)
    query_client = bigquery.Client.from_service_account_json("bqkey.json")
else:
    storage_client = storage.Client()
    query_client = bigquery.Client()

logging_client = logging.Client()
log_name = 'Reconciliation'
logger = logging_client.logger(log_name)    
logger.log_text('Downloading weights...')

if not os.path.isfile('/tmp/cat_model_epoch_015.pth'):
    utils.downloadBlob('model_staging','eyes/ResNet50_Models/cat_model_epoch_015.pth', '/tmp/cat_model_epoch_015.pth')
    utils.downloadBlob('model_staging','eyes/ResNet50_Models/dog_model_epoch_015.pth', '/tmp/dog_model_epoch_015.pth')
    


logger.log_text('weights downloaded')
def hello_world(request):
    """Responds to any HTTP request.
    Args:
        request (flask.Request): HTTP request object.
    Returns:
        The response text or any set of values that can be turned into a
        Response object using
        `make_response <http://flask.pocoo.org/docs/1.0/api/#flask.Flask.make_response>`.
    """
    #request_json = request.get_json(silent=True)
    #number = request_json['number_queries']

    """Query those images in the folders socks, koozies and stickers by time of creation"""
    QUERY="""SELECT * 
FROM newsci-1532356874110.divvyup_metadata.reconciliation_input
ORDER BY rand() 
LIMIT 1
"""
    results = query_client.query(QUERY).result()
    logger.log_text(f"We have {results.total_rows} folders of orders in the directories socks, koozies and stickers")
    #key, key_m, source_blob_name, source_blob_name_m, bucket, 'human'
    to_list = [ {"key":str(item['key']),
                 "key_m":str(item['mask_key'])+'m',
                 "bucket": 'divvyup_data',
                 "crop":item['simple_crop'],
                 "mask":item['final_crop'],
                 "classes":item['subject_class']} for item in results if item['subject_class'] in ['dogs','cats','humans']
              ]
    logger.log_text(f'We have {len(to_list)} valid inputs')
    for d_c in to_list:
        utils.human_eyes(d_c)
    logger.log_text('program ended')
    return '200'